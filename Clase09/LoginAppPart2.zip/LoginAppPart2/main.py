from formularios.Login import * 

if __name__ == '__main__':
    app = Login()
    app.mainloop()